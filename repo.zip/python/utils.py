"""Shared paths and helpers."""
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
RAW_CSV = ROOT / "data" / "raw" / "Sample_-_Superstore.csv"
CLEAN_CSV = ROOT / "data" / "processed" / "superstore_clean.csv"
DB_PATH = ROOT / "data" / "processed" / "superstore.db"
SQL_DIR = ROOT / "sql"
SQL_OUT = ROOT / "outputs" / "sql_results"
IMG_DIR = ROOT / "docs" / "images"
BI_DIR = ROOT / "bi" / "powerbi_data"


def connect():
    return sqlite3.connect(DB_PATH)
