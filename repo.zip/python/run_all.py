"""Run the full pipeline end to end:  python python/run_all.py"""
import subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEPS = ["01_clean_and_build_db.py", "02_run_sql_reports.py", "03_analysis_charts_and_models.py",
         "04_build_dashboard.py", "05_build_excel_workbook.py"]

for step in STEPS:
    print(f"\n{'='*70}\nRunning {step}\n{'='*70}")
    subprocess.run([sys.executable, str(HERE / step)], check=True, cwd=HERE)
print("\nPipeline finished successfully.")
