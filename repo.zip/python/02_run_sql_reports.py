"""Step 2: execute every named query in /sql and save each result as a CSV.

Queries are marked in the .sql files with a line:  -- name: <query_name>
Run:  python python/02_run_sql_reports.py
"""
import re
import pandas as pd
from utils import SQL_DIR, SQL_OUT, connect

SKIP = {"01_schema.sql"}


def parse_queries(text: str):
    parts = re.split(r"^-- name:\s*(\S+)\s*$", text, flags=re.M)
    return [(parts[i], parts[i + 1].strip().rstrip(";")) for i in range(1, len(parts), 2)]


def main():
    SQL_OUT.mkdir(parents=True, exist_ok=True)
    con = connect()
    pd.set_option("display.width", 200, "display.max_columns", 20)
    total = 0
    for path in sorted(SQL_DIR.glob("*.sql")):
        if path.name in SKIP:
            continue
        for name, sql in parse_queries(path.read_text()):
            df = pd.read_sql_query(sql, con)
            df.to_csv(SQL_OUT / f"{name}.csv", index=False)
            total += 1
            print(f"\n[{path.name}] {name}  ({len(df)} rows)")
            print(df.head(12).to_string(index=False))
    con.close()
    print(f"\nExecuted {total} queries; results saved to {SQL_OUT}")


if __name__ == "__main__":
    main()
