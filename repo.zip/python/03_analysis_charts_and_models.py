"""Step 3: Python analysis on top of the SQL layer.

  1. Charts for the README / dashboard (saved to docs/images)
  2. What-if scenario: cap discounts and estimate profit impact
  3. Predictive model: which order lines will lose money? (logistic regression + random forest)

Run:  python python/03_analysis_charts_and_models.py   (after steps 1 and 2)
"""
import json
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from utils import ROOT, IMG_DIR, SQL_OUT, connect

warnings.filterwarnings("ignore")
OUT = ROOT / "outputs"
NAVY, TEAL, RED, GREY, GREEN = "#1F3864", "#2A9D8F", "#C0392B", "#8C8C8C", "#2E8B57"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "axes.titlesize": 12, "figure.dpi": 100})
usd_k = FuncFormatter(lambda x, _: f"${x/1000:,.0f}K")


def load_flat() -> pd.DataFrame:
    con = connect()
    df = pd.read_sql_query("SELECT * FROM vw_sales_flat", con)
    con.close()
    df["order_date"] = pd.to_datetime(df["order_date"])
    return df


def save(fig, name):
    IMG_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(IMG_DIR / name, dpi=150, bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------- charts
def charts(df: pd.DataFrame):
    y = pd.read_csv(SQL_OUT / "q02_yearly_performance_with_yoy.csv")
    fig, ax = plt.subplots(figsize=(8, 4.5))
    x = np.arange(len(y)); w = 0.38
    ax.bar(x - w/2, y["sales"], w, label="Sales", color=NAVY)
    ax.bar(x + w/2, y["profit"], w, label="Profit", color=TEAL)
    ax.set_xticks(x, y["year"]); ax.yaxis.set_major_formatter(usd_k)
    ax2 = ax.twinx(); ax2.plot(x, y["margin_pct"], color=RED, marker="o", label="Profit margin %")
    ax2.set_ylim(0, 20); ax2.set_ylabel("Profit margin %"); ax2.spines["right"].set_visible(True)
    for i, m in enumerate(y["margin_pct"]): ax2.annotate(f"{m}%", (i, m), textcoords="offset points", xytext=(0, 9), ha="center", color=RED, fontsize=9, fontweight="bold", bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.9))
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper left", frameon=False)
    ax.set_title("Sales, profit and margin by year"); save(fig, "01_yearly_performance.png")

    m = pd.read_csv(SQL_OUT / "q03_monthly_trend_with_3m_moving_avg.csv")
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.bar(range(len(m)), m["sales"], color="#B8C4DB", label="Monthly sales")
    ax.plot(range(len(m)), m["sales_3m_avg"], color=NAVY, lw=2, label="3-month moving average")
    ticks = [i for i, v in enumerate(m["year_month"]) if v.endswith("-01")]
    ax.set_xticks(ticks, [m["year_month"][i][:4] for i in ticks]); ax.yaxis.set_major_formatter(usd_k)
    ax.legend(frameon=False); ax.set_title("Monthly sales with strong Q4 seasonality"); save(fig, "02_monthly_trend.png")

    c = pd.read_csv(SQL_OUT / "q06_category_performance.csv")
    fig, axs = plt.subplots(1, 2, figsize=(10, 4))
    xx = np.arange(len(c)); w = 0.38
    axs[0].bar(xx - w/2, c["pct_of_sales"], w, color=NAVY, label="% of sales")
    axs[0].bar(xx + w/2, c["pct_of_profit"], w, color=TEAL, label="% of profit")
    axs[0].set_xticks(xx, c["category"]); axs[0].legend(frameon=False); axs[0].set_title("Share of sales vs share of profit")
    axs[1].bar(c["category"], c["margin_pct"], color=[GREEN if v > 10 else RED for v in c["margin_pct"]])
    for i, v in enumerate(c["margin_pct"]): axs[1].text(i, v + 0.3, f"{v}%", ha="center")
    axs[1].set_title("Profit margin by category")
    save(fig, "03_category_performance.png")

    s = pd.read_csv(SQL_OUT / "q07_subcategory_ranking_within_category.csv").sort_values("profit")
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(s["sub_category"], s["profit"], color=[RED if v < 0 else TEAL for v in s["profit"]])
    ax.xaxis.set_major_formatter(usd_k); ax.axvline(0, color="black", lw=0.8)
    ax.set_title("Profit by sub-category (Tables, Bookcases and Supplies lose money)"); save(fig, "04_subcategory_profit.png")

    d = pd.read_csv(SQL_OUT / "q13_discount_band_profitability.csv")
    d["label"] = d["discount_band"].str.replace(r"^\d\. ", "", regex=True)
    fig, axs = plt.subplots(1, 2, figsize=(11, 4))
    axs[0].bar(d["label"], d["profit"], color=[RED if v < 0 else TEAL for v in d["profit"]])
    axs[0].yaxis.set_major_formatter(usd_k); axs[0].axhline(0, color="black", lw=0.8)
    axs[0].set_title("Profit by discount band"); axs[0].tick_params(axis="x", rotation=30)
    axs[1].bar(d["label"], d["margin_pct"], color=[RED if v < 0 else TEAL for v in d["margin_pct"]])
    axs[1].axhline(0, color="black", lw=0.8); axs[1].set_title("Profit margin % by discount band"); axs[1].tick_params(axis="x", rotation=30)
    save(fig, "05_discount_bands.png")

    fig, ax = plt.subplots(figsize=(8, 4.5))
    jitter = df["discount"] + np.random.default_rng(1).normal(0, 0.004, len(df))
    margin = (df["profit"] / df["sales"]).clip(-2, 1)
    ax.scatter(jitter, margin, s=5, alpha=0.25, color=NAVY)
    ax.axhline(0, color=RED, lw=1); ax.axvline(0.2, color=GREY, ls="--", lw=1)
    ax.text(0.205, 0.85, "20% discount line", color=GREY, fontsize=9)
    ax.set_xlabel("Discount"); ax.set_ylabel("Profit margin per order line (clipped at -200%)")
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.0%}"))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:.0%}"))
    ax.set_title("Every order line: margin collapses as discount rises"); save(fig, "06_discount_vs_margin_scatter.png")

    r = pd.read_csv(SQL_OUT / "q09_region_performance.csv")
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.scatter(r["avg_discount_pct"], r["margin_pct"], s=r["sales"] / 1500, color=NAVY, alpha=0.7)
    for _, row in r.iterrows(): ax.annotate(row["region"], (row["avg_discount_pct"], row["margin_pct"]), xytext=(8, 6), textcoords="offset points")
    ax.set_xlabel("Average discount %"); ax.set_ylabel("Profit margin %"); ax.set_xlim(8, 27); ax.set_ylim(5, 17)
    ax.set_title("Regions: higher discount, lower margin (bubble = sales)"); save(fig, "07_region_discount_vs_margin.png")

    st = pd.read_csv(SQL_OUT / "q10_ten_least_profitable_states.csv").sort_values("profit", ascending=False)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.barh(st["state"], st["profit"], color=RED); ax.xaxis.set_major_formatter(usd_k)
    ax.set_title("Ten least profitable states")
    for i, (p, dsc) in enumerate(zip(st["profit"], st["avg_discount_pct"])): ax.text(300, i, f"avg discount {dsc:.0f}%", va="center", fontsize=8, ha="left", color=GREY)
    ax.set_xlim(st["profit"].min() * 1.05, 9000)
    save(fig, "08_least_profitable_states.png")

    cust = df.groupby("customer_id")["profit"].sum().sort_values(ascending=False).reset_index()
    cum = cust["profit"].cumsum() / cust["profit"].sum()
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(np.arange(1, len(cum) + 1) / len(cum) * 100, cum * 100, color=NAVY, lw=2)
    ax.axvline(20, color=GREY, ls="--"); ax.axhline(cum.iloc[int(len(cum) * 0.2) - 1] * 100, color=GREY, ls="--")
    ax.set_xlabel("% of customers (ranked by profit)"); ax.set_ylabel("Cumulative % of profit")
    ax.set_title(f"Top 20% of customers deliver {cum.iloc[int(len(cum)*0.2)-1]:.0%} of profit"); save(fig, "09_customer_pareto.png")


# ----------------------------------------------------------------------------- scenario
def discount_cap_scenario(df: pd.DataFrame) -> pd.DataFrame:
    """Estimate profit if discounts above `cap` are cut to `cap`.

    Assumptions (documented in README):
      * Sales is net of discount, so list price = Sales / (1 - Discount).
      * Unit cost is unchanged: cost = Sales - Profit.
      * `retention` = share of affected order lines that still sell after the price rise
        (0% = those lines are lost completely, 100% = no customer reacts).
    """
    base_profit = df["profit"].sum()
    rows = []
    for cap in (0.10, 0.20, 0.30, 0.40):
        affected = df["discount"] > cap
        list_price = df["sales"] / (1 - df["discount"])
        new_sales = list_price * (1 - cap)
        cost = df["sales"] - df["profit"]
        new_line_profit = new_sales - cost
        for ret in (1.0, 0.75, 0.5, 0.25, 0.0):
            scenario = np.where(affected, ret * new_line_profit, df["profit"]).sum()
            rows.append({"discount_cap": f"{cap:.0%}", "volume_retained_on_affected_lines": f"{ret:.0%}",
                         "scenario_profit": round(scenario), "baseline_profit": round(base_profit),
                         "profit_uplift": round(scenario - base_profit),
                         "uplift_pct": round(100 * (scenario / base_profit - 1), 1)})
    res = pd.DataFrame(rows)
    res.to_csv(OUT / "scenario_discount_cap.csv", index=False)

    piv = res.pivot(index="discount_cap", columns="volume_retained_on_affected_lines", values="uplift_pct")
    piv = piv[["100%", "75%", "50%", "25%", "0%"]]
    fig, ax = plt.subplots(figsize=(7, 3.6))
    im = ax.imshow(piv.values, cmap="Greens", aspect="auto")
    ax.set_xticks(range(piv.shape[1]), piv.columns); ax.set_yticks(range(piv.shape[0]), piv.index)
    ax.set_xlabel("Share of affected order lines still sold after price rise"); ax.set_ylabel("Discount cap")
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]): ax.text(j, i, f"+{piv.values[i, j]:.0f}%", ha="center", va="center", fontsize=9)
    ax.set_title("Profit uplift vs today under a discount cap"); ax.spines[:].set_visible(False)
    save(fig, "10_discount_cap_scenario.png")
    return res


# ----------------------------------------------------------------------------- model
def loss_model(df: pd.DataFrame) -> dict:
    d = df.copy()
    d["is_loss"] = (d["profit"] < 0).astype(int)
    d["log_sales"] = np.log1p(d["sales"])
    num = ["discount", "log_sales", "quantity"]
    cat = ["category", "sub_category", "region", "segment", "ship_mode"]
    X, y = d[num + cat], d["is_loss"]
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    pre = ColumnTransformer([("num", StandardScaler(), num), ("cat", OneHotEncoder(handle_unknown="ignore"), cat)])
    models = {
        "Logistic regression": Pipeline([("pre", pre), ("clf", LogisticRegression(max_iter=1000))]),
        "Random forest": Pipeline([("pre", pre), ("clf", RandomForestClassifier(n_estimators=300, min_samples_leaf=5, random_state=42, n_jobs=-1))]),
    }
    results = {}
    rule_pred = (Xte["discount"] > 0.2).astype(int)
    results["Rule: discount > 20%"] = {"AUC": float("nan"), "Accuracy": accuracy_score(yte, rule_pred),
                                       "Precision": precision_score(yte, rule_pred), "Recall": recall_score(yte, rule_pred)}
    fitted = {}
    for name, mdl in models.items():
        mdl.fit(Xtr, ytr); fitted[name] = mdl
        proba = mdl.predict_proba(Xte)[:, 1]; pred = (proba >= 0.5).astype(int)
        results[name] = {"AUC": roc_auc_score(yte, proba), "Accuracy": accuracy_score(yte, pred),
                         "Precision": precision_score(yte, pred), "Recall": recall_score(yte, pred)}
    res = pd.DataFrame(results).T.round(3)
    res.to_csv(OUT / "model_performance.csv")

    rf = fitted["Random forest"]
    imp = permutation_importance(rf, Xte, yte, scoring="roc_auc", n_repeats=5, random_state=42, n_jobs=-1)
    fi = pd.Series(imp.importances_mean, index=X.columns).sort_values()
    fi.to_csv(OUT / "feature_importance.csv", header=["auc_drop_when_shuffled"])
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.barh(fi.index, fi.values, color=[RED if v == fi.max() else NAVY for v in fi.values])
    ax.set_xlabel("Drop in AUC when the feature is shuffled"); ax.set_title("What predicts a loss-making order line?")
    save(fig, "11_feature_importance.png")
    return {"table": res, "importance": fi}


def main():
    OUT.mkdir(exist_ok=True)
    df = load_flat()
    charts(df)
    sc = discount_cap_scenario(df)
    mod = loss_model(df)
    print("\nDiscount-cap scenario (profit uplift %):")
    print(sc.pivot(index="discount_cap", columns="volume_retained_on_affected_lines", values="uplift_pct").to_string())
    print("\nLoss-prediction models (25% hold-out test set):")
    print(mod["table"].to_string())
    print("\nPermutation importance (AUC drop):")
    print(mod["importance"].sort_values(ascending=False).round(4).to_string())
    print(f"\nCharts saved to {IMG_DIR}")


if __name__ == "__main__":
    main()
