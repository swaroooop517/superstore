"""Step 1: clean the raw CSV, build the SQLite star schema, export BI-ready tables.

Run:  python python/01_clean_and_build_db.py
"""
import sqlite3
import pandas as pd
from utils import RAW_CSV, CLEAN_CSV, DB_PATH, SQL_DIR, BI_DIR


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [c.strip() for c in df.columns]
    for c in df.columns:
        if pd.api.types.is_string_dtype(df[c]):
            df[c] = df[c].str.strip()
    df["Order Date"] = pd.to_datetime(df["Order Date"], format="%m/%d/%Y")
    df["Ship Date"] = pd.to_datetime(df["Ship Date"], format="%m/%d/%Y")
    df["Postal Code"] = df["Postal Code"].astype(str).str.zfill(5)
    return df


def data_quality_report(df: pd.DataFrame) -> None:
    print("--- Data quality report ---")
    print(f"Rows: {len(df):,} | Columns: {df.shape[1]}")
    print(f"Missing values: {int(df.isna().sum().sum())}")
    print(f"Fully duplicated rows: {int(df.duplicated().sum())}")
    print(f"Ship date before order date: {int((df['Ship Date'] < df['Order Date']).sum())}")
    multi = df.groupby("Product ID")["Product Name"].nunique().gt(1).sum()
    print(f"Product IDs with more than one product name: {int(multi)}  (handled via composite product key)")
    print(f"Order date range: {df['Order Date'].min().date()} to {df['Order Date'].max().date()}")


def build_dimensions(df: pd.DataFrame):
    dates = pd.date_range(
        min(df["Order Date"].min(), df["Ship Date"].min()),
        max(df["Order Date"].max(), df["Ship Date"].max()),
    )
    dim_date = pd.DataFrame({
        "date_key": dates.strftime("%Y%m%d").astype(int),
        "full_date": dates.strftime("%Y-%m-%d"),
        "year": dates.year,
        "quarter": dates.quarter,
        "month": dates.month,
        "month_name": dates.strftime("%B"),
        "year_month": dates.strftime("%Y-%m"),
        "day_of_week": dates.strftime("%A"),
    })
    dim_customer = (df[["Customer ID", "Customer Name", "Segment"]].drop_duplicates("Customer ID")
                    .rename(columns={"Customer ID": "customer_id", "Customer Name": "customer_name", "Segment": "segment"})
                    .sort_values("customer_id").reset_index(drop=True))
    loc = (df[["Country", "Region", "State", "City", "Postal Code"]].drop_duplicates()
           .sort_values(["Country", "Region", "State", "City", "Postal Code"]).reset_index(drop=True))
    loc.insert(0, "location_key", range(1, len(loc) + 1))
    dim_location = loc.rename(columns={"Country": "country", "Region": "region", "State": "state",
                                       "City": "city", "Postal Code": "postal_code"})
    prod = (df[["Product ID", "Product Name", "Category", "Sub-Category"]].drop_duplicates(["Product ID", "Product Name"])
            .sort_values(["Product ID", "Product Name"]).reset_index(drop=True))
    prod.insert(0, "product_key", range(1, len(prod) + 1))
    dim_product = prod.rename(columns={"Product ID": "product_id", "Product Name": "product_name",
                                       "Category": "category", "Sub-Category": "sub_category"})
    ship = pd.DataFrame({"ship_mode": sorted(df["Ship Mode"].unique())})
    ship.insert(0, "ship_mode_key", range(1, len(ship) + 1))
    return dim_date, dim_customer, dim_location, dim_product, ship


def build_fact(df, dim_location, dim_product, dim_ship):
    f = df.merge(dim_location.rename(columns={"country": "Country", "region": "Region", "state": "State",
                                              "city": "City", "postal_code": "Postal Code"}),
                 on=["Country", "Region", "State", "City", "Postal Code"], how="left")
    f = f.merge(dim_product.rename(columns={"product_id": "Product ID", "product_name": "Product Name"})[
        ["product_key", "Product ID", "Product Name"]], on=["Product ID", "Product Name"], how="left")
    f = f.merge(dim_ship.rename(columns={"ship_mode": "Ship Mode"}), on="Ship Mode", how="left")
    assert f[["location_key", "product_key", "ship_mode_key"]].notna().all().all(), "unmatched dimension keys"
    fact = pd.DataFrame({
        "row_id": f["Row ID"],
        "order_id": f["Order ID"],
        "order_date_key": f["Order Date"].dt.strftime("%Y%m%d").astype(int),
        "ship_date_key": f["Ship Date"].dt.strftime("%Y%m%d").astype(int),
        "customer_id": f["Customer ID"],
        "location_key": f["location_key"].astype(int),
        "product_key": f["product_key"].astype(int),
        "ship_mode_key": f["ship_mode_key"].astype(int),
        "sales": f["Sales"], "quantity": f["Quantity"],
        "discount": f["Discount"], "profit": f["Profit"],
    })
    return fact


def main():
    raw = pd.read_csv(RAW_CSV, encoding="latin1")
    df = clean(raw)
    data_quality_report(df)
    CLEAN_CSV.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(CLEAN_CSV, index=False)

    dim_date, dim_customer, dim_location, dim_product, dim_ship = build_dimensions(df)
    fact = build_fact(df, dim_location, dim_product, dim_ship)

    if DB_PATH.exists():
        DB_PATH.unlink()
    con = sqlite3.connect(DB_PATH)
    con.executescript((SQL_DIR / "01_schema.sql").read_text())
    for name, table in [("dim_date", dim_date), ("dim_customer", dim_customer), ("dim_location", dim_location),
                        ("dim_product", dim_product), ("dim_ship_mode", dim_ship), ("fact_sales", fact)]:
        table.to_sql(name, con, if_exists="append", index=False)
    con.commit()
    n = con.execute("SELECT COUNT(*) FROM vw_sales_flat").fetchone()[0]
    assert n == len(df), f"row count mismatch: view {n} vs source {len(df)}"
    # reconciliation check: SQL totals must equal the raw CSV totals
    s, p = con.execute("SELECT SUM(sales), SUM(profit) FROM fact_sales").fetchone()
    assert abs(s - df["Sales"].sum()) < 0.01 and abs(p - df["Profit"].sum()) < 0.01, "totals do not reconcile"
    con.close()

    BI_DIR.mkdir(parents=True, exist_ok=True)
    for name, table in [("dim_date", dim_date), ("dim_customer", dim_customer), ("dim_location", dim_location),
                        ("dim_product", dim_product), ("dim_ship_mode", dim_ship), ("fact_sales", fact)]:
        table.to_csv(BI_DIR / f"{name}.csv", index=False)
    print(f"Built {DB_PATH.name}: {len(fact):,} fact rows, totals reconcile with source CSV.")
    print(f"Exported {6} star-schema CSVs to {BI_DIR}")


if __name__ == "__main__":
    main()
