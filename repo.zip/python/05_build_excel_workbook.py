"""Step 5: build the Excel workbook (formula-driven analysis tabs, charts, key insights).

Every number on the analysis tabs is a live SUMIFS/AVERAGEIFS formula over the Data tab.
Run:  python python/05_build_excel_workbook.py
"""
import pandas as pd
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.utils import get_column_letter as L

df=pd.read_csv(ROOT/'data'/'raw'/'Sample_-_Superstore.csv',encoding='latin1')
df['Order Date']=pd.to_datetime(df['Order Date'],format='%m/%d/%Y')
df['Ship Date']=pd.to_datetime(df['Ship Date'],format='%m/%d/%Y')
N=len(df); last=N+1
F='Arial'
hdr_fill=PatternFill('solid',fgColor='1F3864'); hdr_font=Font(name=F,bold=True,color='FFFFFF',size=10)
base=Font(name=F,size=10); bold=Font(name=F,size=10,bold=True); blue=Font(name=F,size=10,color='0000FF')
title=Font(name=F,size=14,bold=True,color='1F3864'); note=Font(name=F,size=9,italic=True,color='595959')
thin=Side(style='thin',color='BFBFBF')
USD='$#,##0;($#,##0);-'; PCT='0.0%;(0.0%);-'; NUM='#,##0;(#,##0);-'

wb=Workbook()
ws_sum=wb.active; ws_sum.title='Summary'
ws_ins=wb.create_sheet('Key Insights')
ws_d=wb.create_sheet('Data')

# ---- Data
cols=list(df.columns)
for j,c in enumerate(cols,1):
    ws_d.cell(1,j,c)
ws_d.cell(1,len(cols)+1,'Order Year')
for i,row in enumerate(df.itertuples(index=False),2):
    for j,v in enumerate(row,1):
        if isinstance(v,pd.Timestamp): v=v.to_pydatetime()
        ws_d.cell(i,j,v)
    ws_d.cell(i,len(cols)+1,f'=YEAR(C{i})')
for j in range(1,len(cols)+2):
    c=ws_d.cell(1,j); c.fill=hdr_fill; c.font=hdr_font
for r in ws_d.iter_rows(min_row=2,max_row=last):
    for c in r: c.font=base
    r[2].number_format='m/d/yyyy'; r[3].number_format='m/d/yyyy'
    r[17].number_format='#,##0.00'; r[20].number_format='#,##0.00'
ws_d.freeze_panes='A2'; ws_d.auto_filter.ref=f'A1:{L(len(cols)+1)}{last}'
for j in range(1,len(cols)+2): ws_d.column_dimensions[L(j)].width=14
ws_d.column_dimensions['Q'].width=40

R=lambda col:f'Data!${col}$2:${col}${last}'
SALES,QTY,DISC,PROF=R('R'),R('S'),R('T'),R('U')
DIM={'Year':R('V'),'Category':R('O'),'Sub-Category':R('P'),'Region':R('M'),'Segment':R('H'),'State':R('K'),'Ship Mode':R('E')}

def style_header(ws,row,c1,c2):
    for c in range(c1,c2+1):
        x=ws.cell(row,c); x.fill=hdr_fill; x.font=hdr_font; x.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)

def dim_sheet(name,dimkey,labels,ttl,extra_note=None):
    ws=wb.create_sheet(name)
    ws['A1']=ttl; ws['A1'].font=title
    heads=[dimkey,'Sales ($)','Profit ($)','Profit Margin','Units Sold','Avg Discount','% of Total Sales','% of Total Profit']
    for j,h in enumerate(heads,1): ws.cell(3,j,h)
    style_header(ws,3,1,8)
    r0=4
    for i,lab in enumerate(labels):
        r=r0+i
        ws.cell(r,1,lab)
        ws.cell(r,2,f'=SUMIFS({SALES},{DIM[dimkey]},$A{r})')
        ws.cell(r,3,f'=SUMIFS({PROF},{DIM[dimkey]},$A{r})')
        ws.cell(r,4,f'=IF(B{r}=0,0,C{r}/B{r})')
        ws.cell(r,5,f'=SUMIFS({QTY},{DIM[dimkey]},$A{r})')
        ws.cell(r,6,f'=AVERAGEIFS({DISC},{DIM[dimkey]},$A{r})')
        ws.cell(r,7,f'=B{r}/B${r0+len(labels)}')
        ws.cell(r,8,f'=C{r}/C${r0+len(labels)}')
    rt=r0+len(labels)
    ws.cell(rt,1,'Total')
    ws.cell(rt,2,f'=SUM(B{r0}:B{rt-1})'); ws.cell(rt,3,f'=SUM(C{r0}:C{rt-1})')
    ws.cell(rt,4,f'=C{rt}/B{rt}'); ws.cell(rt,5,f'=SUM(E{r0}:E{rt-1})')
    ws.cell(rt,6,f'=AVERAGE({DISC})'); ws.cell(rt,7,f'=SUM(G{r0}:G{rt-1})'); ws.cell(rt,8,f'=SUM(H{r0}:H{rt-1})')
    for r in range(r0,rt+1):
        for j in range(1,9):
            c=ws.cell(r,j); c.font=bold if r==rt else base
            c.number_format={1:'@',2:USD,3:USD,4:PCT,5:NUM,6:PCT,7:PCT,8:PCT}[j]
            if r==rt: c.border=Border(top=thin)
    ws.column_dimensions['A'].width=22
    for j in range(2,9): ws.column_dimensions[L(j)].width=15
    ws.row_dimensions[3].height=30
    if extra_note: ws.cell(rt+2,1,extra_note).font=note
    ws.freeze_panes='A4'
    return ws,r0,rt

def bar(ws,anchor,ttl,cats,datas,yfmt=None,w=18,h=9,horizontal=False,ytitle=None):
    ch=BarChart(); ch.type='bar' if horizontal else 'col'; ch.title=ttl; ch.style=10
    for d in datas: ch.add_data(d,titles_from_data=True)
    ch.set_categories(cats); ch.width=w; ch.height=h
    ch.roundedCorners=False; ch.title.overlay=False
    ch.x_axis.delete=False; ch.y_axis.delete=False
    if yfmt: ch.y_axis.number_format=yfmt; ch.y_axis.numFmt.sourceLinked=False if ch.y_axis.numFmt else None
    if ytitle:
        ch.y_axis.title=ytitle; ch.y_axis.title.overlay=False
    if len(datas)>1:
        ch.legend.position='b'; ch.legend.overlay=False
    else: ch.legend=None
    ws.add_chart(ch,anchor); return ch

# Year
years=[2014,2015,2016,2017]
ws_y,r0,rt=dim_sheet('By Year','Year',years,'Performance by Year')
for r in range(r0,rt): ws_y.cell(r,1).number_format='0'; ws_y.cell(r,1).alignment=Alignment(horizontal='left')
ws_y['J3']='Sales YoY Growth'; ws_y['K3']='Profit YoY Growth'; style_header(ws_y,3,10,11)
for r in range(r0+1,rt):
    ws_y.cell(r,10,f'=B{r}/B{r-1}-1').number_format=PCT; ws_y.cell(r,11,f'=C{r}/C{r-1}-1').number_format=PCT
    ws_y.cell(r,10).font=base; ws_y.cell(r,11).font=base
ws_y['A11']='Sales CAGR 2014-2017'; ws_y['B11']=f'=(B{rt-1}/B{r0})^(1/(A{rt-1}-A{r0}))-1'
ws_y['A12']='Profit CAGR 2014-2017'; ws_y['B12']=f'=(C{rt-1}/C{r0})^(1/(A{rt-1}-A{r0}))-1'
for c in ('A11','A12'): ws_y[c].font=bold
for c in ('B11','B12'): ws_y[c].font=base; ws_y[c].number_format=PCT
ws_y.column_dimensions['J'].width=16; ws_y.column_dimensions['K'].width=16
bar(ws_y,'A15','Sales vs Profit by Year ($)',Reference(ws_y,min_col=1,min_row=r0,max_row=rt-1),
    [Reference(ws_y,min_col=2,min_row=3,max_row=rt-1),Reference(ws_y,min_col=3,min_row=3,max_row=rt-1)],yfmt='$#,##0')
ws_y_ref=(r0,rt)

# Category
cats=['Furniture','Office Supplies','Technology']
ws_c,cr0,crt=dim_sheet('By Category','Category',cats,'Performance by Category')
bar(ws_c,'A10','Profit Margin by Category',Reference(ws_c,min_col=1,min_row=cr0,max_row=crt-1),[Reference(ws_c,min_col=4,min_row=3,max_row=crt-1)],yfmt='0%')

# Sub-category sorted by profit
sub=df.groupby('Sub-Category').Profit.sum().sort_values().index.tolist()
ws_s,sr0,srt=dim_sheet('By Sub-Category','Sub-Category',sub,'Performance by Sub-Category (sorted by profit, lowest first)')
bar(ws_s,'A25','Profit by Sub-Category ($)',Reference(ws_s,min_col=1,min_row=sr0,max_row=srt-1),[Reference(ws_s,min_col=3,min_row=3,max_row=srt-1)],yfmt='$#,##0',w=22,h=11,horizontal=True)

# Region
regs=df.groupby('Region').Profit.sum().sort_values().index.tolist()
ws_r,rr0,rrt=dim_sheet('By Region','Region',regs,'Performance by Region')
bar(ws_r,'A11','Profit Margin & Avg Discount by Region',Reference(ws_r,min_col=1,min_row=rr0,max_row=rrt-1),
    [Reference(ws_r,min_col=4,min_row=3,max_row=rrt-1),Reference(ws_r,min_col=6,min_row=3,max_row=rrt-1)],yfmt='0%')

# Segment
segs=['Consumer','Corporate','Home Office']
ws_g,gr0,grt=dim_sheet('By Segment','Segment',segs,'Performance by Customer Segment')
bar(ws_g,'A10','Profit Margin by Segment',Reference(ws_g,min_col=1,min_row=gr0,max_row=grt-1),[Reference(ws_g,min_col=4,min_row=3,max_row=grt-1)],yfmt='0%')

# State (sorted by profit)
st=df.groupby('State').Profit.sum().sort_values().index.tolist()
ws_st,str0,strt=dim_sheet('By State','State',st,'Performance by State (sorted by profit, lowest first)')
bar(ws_st,'J3','10 Least Profitable States ($)',Reference(ws_st,min_col=1,min_row=str0,max_row=str0+9),[Reference(ws_st,min_col=3,min_row=3,max_row=str0+9)],yfmt='$#,##0',w=18,h=9)
# fix: header row 3 + rows 4..13 is contiguous so titles_from_data ok

# Discount
ws_x=wb.create_sheet('Discount Impact')
ws_x['A1']='Discount Impact on Profitability'; ws_x['A1'].font=title
heads=['Discount Band','Lower (>)','Upper (<=)','Order Lines','Sales ($)','Profit ($)','Profit Margin','% of Total Profit']
for j,h in enumerate(heads,1): ws_x.cell(3,j,h)
style_header(ws_x,3,1,8)
bands=[('No discount',-1,0),('Up to 10%',0,0.10),('10-20%',0.10,0.20),('20-30%',0.20,0.30),('30-50%',0.30,0.50),('Above 50%',0.50,1.0)]
for i,(n,lo,hi) in enumerate(bands):
    r=4+i
    ws_x.cell(r,1,n); ws_x.cell(r,2,lo); ws_x.cell(r,3,hi)
    ws_x.cell(r,4,f'=COUNTIFS({DISC},">"&B{r},{DISC},"<="&C{r})')
    ws_x.cell(r,5,f'=SUMIFS({SALES},{DISC},">"&B{r},{DISC},"<="&C{r})')
    ws_x.cell(r,6,f'=SUMIFS({PROF},{DISC},">"&B{r},{DISC},"<="&C{r})')
    ws_x.cell(r,7,f'=IF(E{r}=0,0,F{r}/E{r})'); ws_x.cell(r,8,f'=F{r}/F$10')
ws_x.cell(10,1,'Total')
for j,col in ((4,'D'),(5,'E'),(6,'F'),(8,'H')): ws_x.cell(10,j,f'=SUM({col}4:{col}9)')
ws_x.cell(10,7,'=F10/E10')
for r in range(4,11):
    for j in range(1,9):
        c=ws_x.cell(r,j); c.font=bold if r==10 else base
        c.number_format={1:'@',2:'0%',3:'0%',4:NUM,5:USD,6:USD,7:PCT,8:PCT}[j]
        if j in (2,3) and r<10: c.font=blue
ws_x['A12']='Band limits (blue) are inputs: a line is in a band if Discount > Lower and <= Upper.'; ws_x['A12'].font=note
ws_x.column_dimensions['A'].width=18
for j in range(2,9): ws_x.column_dimensions[L(j)].width=15
bar(ws_x,'A14','Profit by Discount Band ($)',Reference(ws_x,min_col=1,min_row=4,max_row=9),[Reference(ws_x,min_col=6,min_row=3,max_row=9)],yfmt='$#,##0')

# Category x Region matrix
ws_m=wb.create_sheet('Category x Region')
ws_m['A1']='Profit Margin: Category x Region'; ws_m['A1'].font=title
rg=['Central','East','South','West']
ws_m['A3']='Category'; 
for j,g in enumerate(rg,2): ws_m.cell(3,j,g)
style_header(ws_m,3,1,5)
for i,c in enumerate(cats):
    r=4+i; ws_m.cell(r,1,c).font=base
    for j in range(2,6):
        col=L(j)
        ws_m.cell(r,j,f'=SUMIFS({PROF},{DIM["Category"]},$A{r},{DIM["Region"]},{col}$3)/SUMIFS({SALES},{DIM["Category"]},$A{r},{DIM["Region"]},{col}$3)').number_format=PCT
        ws_m.cell(r,j).font=base
ws_m.column_dimensions['A'].width=20
for j in range(2,6): ws_m.column_dimensions[L(j)].width=14
from openpyxl.formatting.rule import ColorScaleRule
ws_m.conditional_formatting.add('B4:E6',ColorScaleRule(start_type='min',start_color='F8696B',mid_type='num',mid_value=0.1,mid_color='FFFFFF',end_type='max',end_color='63BE7B'))

# ---- Summary
ws=ws_sum
ws['A1']='Business & Financial Performance Analysis'; ws['A1'].font=Font(name=F,size=16,bold=True,color='1F3864')
ws['A2']='Sample Superstore | US retail | Jan 2014 - Dec 2017 | All figures in USD'; ws['A2'].font=note
ws['A4']='Key Performance Indicators'; ws['A4'].font=Font(name=F,size=12,bold=True)
k=[('Total Sales',f'=SUM({SALES})',USD),('Total Profit',f'=SUM({PROF})',USD),('Overall Profit Margin','=B6/B5',PCT),
   ('Units Sold',f'=SUM({QTY})',NUM),('Order Lines',f'=COUNT({SALES})',NUM),
   ('Unique Orders',5009,NUM),('Unique Customers',793,NUM),
   ('Average Order Value','=B5/B10',USD),('Avg Profit per Order','=B6/B10',USD),
   ('Average Discount',f'=AVERAGE({DISC})',PCT),
   ('Loss-making Order Lines %',f'=COUNTIF({PROF},"<0")/COUNT({PROF})',PCT),
   ('Total Losses on Loss-making Lines',f'=SUMIF({PROF},"<0")',USD),
   ('Sales CAGR (2014-17)',"='By Year'!B11",PCT),('Profit CAGR (2014-17)',"='By Year'!B12",PCT)]
for i,(a,b,f) in enumerate(k):
    r=5+i; ws.cell(r,1,a).font=base; c=ws.cell(r,2,b); c.number_format=f
    c.font=blue if isinstance(b,int) else (Font(name=F,size=10,color='008000') if str(b).startswith("='") else base)
ws['C10']='Distinct count of Order ID, computed from the dataset (hardcoded input)'; ws['C11']='Distinct count of Customer ID, computed from the dataset (hardcoded input)'
ws['C10'].font=note; ws['C11'].font=note
ws['A21']='Workbook guide'; ws['A21'].font=Font(name=F,size=12,bold=True)
guide=['Key Insights: headline findings and recommendations','By Year / Category / Sub-Category / Region / Segment / State: SUMIFS-driven tables and charts',
       'Discount Impact: how discount depth drives profit (editable band limits)','Category x Region: margin heat map','Data: cleaned source data (dates converted, Order Year added)']
for i,g in enumerate(guide): ws.cell(22+i,1,g).font=base
ws.column_dimensions['A'].width=38; ws.column_dimensions['B'].width=18; ws.column_dimensions['C'].width=70
ws['A28']='Colour code: blue = hardcoded input, black = formula, green = link to another sheet.'; ws['A28'].font=note
bar(ws,'E4','Annual Sales vs Profit ($)',Reference(ws_y,min_col=1,min_row=4,max_row=7),[Reference(ws_y,min_col=2,min_row=3,max_row=7),Reference(ws_y,min_col=3,min_row=3,max_row=7)],yfmt='$#,##0',w=16,h=8.5)

# ---- Insights
ws=ws_ins
ws['A1']='Key Insights & Recommendations'; ws['A1'].font=title
ins=[('1. Growth is strong, profitability is not keeping pace',
 'Sales grew from $484K (2014) to $733K (2017), a ~14.9% CAGR; profit rose from $49.5K to $93.4K. Margin peaked at 13.4% in 2016 and slipped to 12.7% in 2017 as sales grew faster than profit.'),
('2. Furniture is the weak spot',
 'Furniture generates $742K of sales (32% of total) but only $18K profit, a 2.5% margin vs 17% for Office Supplies and 17.4% for Technology. Tables (-8.6%), Bookcases (-3.0%) and Supplies (-2.5%) lose money.'),
('3. Discounting destroys profit',
 'Lines with no discount earn a 29.5% margin and contribute $321K of profit. Lines discounted 20%+ lose money: 20-30% = -10.0%, 30-50% = -24.8%, above 50% = -119%. Together these discount bands lose about $135K.'),
('4. Central region and a few states drag results',
 'Central has the highest average discount (24%) and the lowest margin (7.9%). Texas, Ohio, Pennsylvania and Illinois lose $15-26K each. Low-discount states such as Michigan (0.7%) and Virginia (0%) earn 26-32% margins.'),
('5. Segment mix is healthy',
 'Consumer is 51% of sales at an 11.5% margin; Home Office has the best margin at 14.0%, with Corporate at 13.0%. Segment is not a major problem area.'),
('6. About 19% of order lines lose money',
 '1,871 order lines (18.7%) are loss-making, totalling roughly $156K of losses, over half of the $286K net profit.')]
r=3
for h,t in ins:
    ws.cell(r,1,h).font=bold; ws.cell(r+1,1,t).font=base; ws.cell(r+1,1).alignment=Alignment(wrap_text=True,vertical='top'); ws.row_dimensions[r+1].height=48; r+=3
ws.cell(r,1,'Recommendations').font=Font(name=F,size=12,bold=True); r+=1
recs=['Cap discounts at 20%; require approval for anything higher (the 30%+ bands lose roughly $125K).',
 'Reprice or rationalise Tables and Bookcases; review supplier cost and discount policy before further volume growth.',
 'Run a discount audit in Central and in TX, OH, PA, IL; replicate the discipline seen in the West and East.',
 'Shift marketing spend toward high-margin lines (Copiers, Paper, Accessories, Phones, Envelopes, Labels).',
 'Track margin, not just sales growth, as a headline KPI in monthly reviews.']
for t in recs:
    ws.cell(r,1,'- '+t).font=base; ws.cell(r,1).alignment=Alignment(wrap_text=True); r+=1
ws.cell(r+1,1,'Figures quoted above are static text taken from the analysis tabs at time of writing.').font=note
ws.column_dimensions['A'].width=120

(ROOT/'excel').mkdir(exist_ok=True)
wb.save(ROOT/'excel'/'Superstore_Business_Financial_Analysis.xlsx')
print('Workbook written to excel/Superstore_Business_Financial_Analysis.xlsx (open in Excel to calculate formulas)')
