"""Step 4: build the interactive dashboard (docs/index.html) that GitHub Pages serves.

The dashboard is a single static HTML file (Chart.js loaded from a CDN). The data is a small
pre-aggregated "cube" embedded in the page, so every filter works with no server.

Run:  python python/04_build_dashboard.py
"""
import json
import pandas as pd
from utils import ROOT, SQL_OUT, connect

TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Superstore Business &amp; Financial Performance Dashboard</title>
<style>
:root{--bg:#f5f7fb;--card:#fff;--ink:#1b2437;--muted:#667085;--line:#e3e8f0;--navy:#1F3864;--teal:#2A9D8F;--red:#C0392B;--accent:#3b5ba9}
@media (prefers-color-scheme:dark){:root{--bg:#10151f;--card:#18202e;--ink:#e8edf6;--muted:#9aa6bb;--line:#2a3447;--navy:#7fa0e6;--teal:#3fc2b2;--red:#ef6a5b;--accent:#7fa0e6}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
header{padding:22px 28px 6px}h1{margin:0;font-size:22px}header p{margin:4px 0 0;color:var(--muted);font-size:13px}
.filters{display:flex;flex-wrap:wrap;gap:12px;padding:12px 28px;align-items:end}
.filters label{font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:4px}
select,button{font:inherit;padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--ink)}
button{cursor:pointer}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;padding:6px 28px}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}
.kpi .l{font-size:12px;color:var(--muted)}.kpi .v{font-size:22px;font-weight:700;margin-top:4px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:14px;padding:14px 28px 6px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}
.card h3{margin:0 0 2px;font-size:14px}.card p{margin:0 0 8px;font-size:12px;color:var(--muted)}
.box{position:relative;height:290px}.box.tall{height:420px}
.insights{padding:6px 28px 28px}.insights ul{margin:6px 0 0;padding-left:18px;line-height:1.6;font-size:14px}
footer{padding:0 28px 28px;color:var(--muted);font-size:12px}
a{color:var(--accent)}
</style>
</head>
<body>
<header>
<h1>Superstore Business &amp; Financial Performance</h1>
<p>US retail transactions, Jan 2014 - Dec 2017 &middot; 9,994 order lines &middot; Source: Sample Superstore dataset &middot; Pipeline: SQL + Python</p>
</header>
<div class="filters">
<label>Year<select id="f-year"></select></label>
<label>Region<select id="f-region"></select></label>
<label>Category<select id="f-category"></select></label>
<label>Segment<select id="f-segment"></select></label>
<button id="reset">Reset filters</button>
</div>
<section class="kpis" id="kpis"></section>
<section class="grid">
<div class="card"><h3>Sales, profit and margin by year</h3><p>Responds to region, category and segment filters</p><div class="box"><canvas id="c-year"></canvas></div></div>
<div class="card"><h3>Profit by discount band</h3><p>Deeper discounts turn profit negative</p><div class="box"><canvas id="c-band"></canvas></div></div>
<div class="card"><h3>Profit margin by category</h3><p>Furniture earns a thin margin</p><div class="box"><canvas id="c-cat"></canvas></div></div>
<div class="card"><h3>Profit margin by region</h3><p>Central: highest discounts, lowest margin</p><div class="box"><canvas id="c-reg"></canvas></div></div>
<div class="card" style="grid-column:1/-1"><h3>Profit by sub-category</h3><p>Hover for sales and margin</p><div class="box tall"><canvas id="c-sub"></canvas></div></div>
</section>
<section class="insights card" style="margin:0 28px 14px">
<h3>Key findings (full dataset)</h3>
<ul>
<li>Sales grew about 14.8% a year (2014-2017) and profit about 23.6% a year; overall margin is 12.5%.</li>
<li>Furniture is 32% of sales but only 6% of profit (2.5% margin). Tables, Bookcases and Supplies lose money.</li>
<li>Order lines discounted above 20% lose about $135K in total; undiscounted lines earn a 29.5% margin.</li>
<li>The top 20% of customers generate about 81% of profit, while 155 customers are loss-making in total.</li>
</ul>
</section>
<footer>Built with SQL (SQLite) and Python; charts by Chart.js. Source code, SQL and methodology are in the GitHub repository.</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const DATA = __DATA__;
const C = {year:0,region:1,category:2,sub:3,segment:4,band:5,sales:6,profit:7,qty:8,lines:9};
const state = {year:'All',region:'All',category:'All',segment:'All'};
const css = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const money = v => (v<0?'-':'')+'$'+Math.abs(Math.round(v)).toLocaleString('en-US');
const kmoney = v => (v<0?'-':'')+'$'+Math.round(Math.abs(v)/1000).toLocaleString('en-US')+'K';
const pct = v => (v*100).toFixed(1)+'%';

function uniq(i){return [...new Set(DATA.rows.map(r=>r[i]))].sort();}
function fillSelect(id,key,idx){
  const el=document.getElementById(id);
  el.innerHTML='<option>All</option>'+uniq(idx).map(v=>'<option>'+v+'</option>').join('');
  el.addEventListener('change',()=>{state[key]=el.value;render();});
}
fillSelect('f-year','year',C.year);fillSelect('f-region','region',C.region);
fillSelect('f-category','category',C.category);fillSelect('f-segment','segment',C.segment);
document.getElementById('reset').addEventListener('click',()=>{
  for(const k in state){state[k]='All';document.getElementById('f-'+k).value='All';}render();});

// rows filtered by every active filter except the ones in `skip`
function rows(skip=[]){
  return DATA.rows.filter(r=>
    (skip.includes('year')||state.year==='All'||String(r[C.year])===state.year) &&
    (skip.includes('region')||state.region==='All'||r[C.region]===state.region) &&
    (skip.includes('category')||state.category==='All'||r[C.category]===state.category) &&
    (skip.includes('segment')||state.segment==='All'||r[C.segment]===state.segment));
}
function group(rs,idx){
  const m=new Map();
  for(const r of rs){
    const k=r[idx];const o=m.get(k)||{sales:0,profit:0,qty:0,lines:0};
    o.sales+=r[C.sales];o.profit+=r[C.profit];o.qty+=r[C.qty];o.lines+=r[C.lines];m.set(k,o);
  }
  return m;
}

const charts={};
function mk(id,cfg){charts[id]=new Chart(document.getElementById(id),cfg);}
const common=()=>({responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{color:css('--ink')}}},
  scales:{x:{ticks:{color:css('--muted')},grid:{display:false}},y:{ticks:{color:css('--muted')},grid:{color:css('--line')}}}});

function render(){
  const rs=rows();
  const tot=rs.reduce((a,r)=>{a.sales+=r[C.sales];a.profit+=r[C.profit];a.qty+=r[C.qty];a.lines+=r[C.lines];return a;},{sales:0,profit:0,qty:0,lines:0});
  const loss=rs.filter(r=>r[C.profit]<0);
  const k=[['Total sales',money(tot.sales)],['Total profit',money(tot.profit)],
    ['Profit margin',tot.sales?pct(tot.profit/tot.sales):'-'],['Units sold',tot.qty.toLocaleString('en-US')],
    ['Order lines',tot.lines.toLocaleString('en-US')]];
  document.getElementById('kpis').innerHTML=k.map(x=>'<div class="kpi"><div class="l">'+x[0]+'</div><div class="v">'+x[1]+'</div></div>').join('');

  // by year (ignores the year filter so the trend always shows every year)
  const gy=group(rows(['year']),C.year);const years=[...gy.keys()].sort();
  upd('c-year',years,[
    {type:'bar',label:'Sales',data:years.map(y=>gy.get(y).sales),backgroundColor:css('--navy'),yAxisID:'y'},
    {type:'bar',label:'Profit',data:years.map(y=>gy.get(y).profit),backgroundColor:css('--teal'),yAxisID:'y'},
    {type:'line',label:'Margin %',data:years.map(y=>gy.get(y).sales?gy.get(y).profit/gy.get(y).sales*100:0),borderColor:css('--red'),backgroundColor:css('--red'),yAxisID:'y2',tension:.25}
  ],{y:{ticks:{callback:v=>kmoney(v)}},y2:{position:'right',grid:{display:false},ticks:{callback:v=>v+'%'},suggestedMin:0,suggestedMax:20}});

  const gb=group(rs,C.band);const bands=[...gb.keys()].sort();
  upd('c-band',bands.map(b=>b.replace(/^\d\. /,'')),[{label:'Profit',data:bands.map(b=>gb.get(b).profit),
    backgroundColor:bands.map(b=>gb.get(b).profit<0?css('--red'):css('--teal'))}],{y:{ticks:{callback:v=>kmoney(v)}}},false);

  const gc=group(rows(['category']),C.category);const cats=[...gc.keys()].sort();
  upd('c-cat',cats,[{label:'Profit margin %',data:cats.map(c=>gc.get(c).sales?gc.get(c).profit/gc.get(c).sales*100:0),
    backgroundColor:cats.map(c=>gc.get(c).profit/gc.get(c).sales<0.05?css('--red'):css('--teal'))}],{y:{ticks:{callback:v=>v+'%'}}},false);

  const gr=group(rows(['region']),C.region);const regs=[...gr.keys()].sort();
  upd('c-reg',regs,[{label:'Profit margin %',data:regs.map(r=>gr.get(r).sales?gr.get(r).profit/gr.get(r).sales*100:0),
    backgroundColor:regs.map(r=>gr.get(r).profit/gr.get(r).sales<0.09?css('--red'):css('--navy'))}],{y:{ticks:{callback:v=>v+'%'}}},false);

  const gs=group(rs,C.sub);const subs=[...gs.keys()].sort((a,b)=>gs.get(a).profit-gs.get(b).profit);
  upd('c-sub',subs,[{label:'Profit',data:subs.map(s=>gs.get(s).profit),
    backgroundColor:subs.map(s=>gs.get(s).profit<0?css('--red'):css('--teal'))}],{x:{ticks:{callback:v=>kmoney(v)}}},false,'y',
    {afterLabel:i=>{const g=gs.get(subs[i.dataIndex]);return 'Sales '+money(g.sales)+' | margin '+(g.sales?pct(g.profit/g.sales):'-');}});
}

function upd(id,labels,datasets,scales,legend=true,axis='x',tooltipExtra){
  const ch=charts[id];
  if(!ch){
    const o=common();
    for(const s in scales){o.scales[s]=Object.assign({},o.scales[s]||{},scales[s]);
      if(scales[s].ticks)o.scales[s].ticks=Object.assign({color:css('--muted')},scales[s].ticks);}
    o.plugins.legend.display=legend;
    if(axis==='y')o.indexAxis='y';
    if(tooltipExtra)o.plugins.tooltip={callbacks:{afterLabel:tooltipExtra.afterLabel}};
    mk(id,{type:'bar',data:{labels,datasets},options:o});
  }else{ch.data.labels=labels;ch.data.datasets=datasets;ch.update();}
}
render();
</script>
</body>
</html>
"""


def build_cube() -> dict:
    con = connect()
    df = pd.read_sql_query("SELECT year, region, category, sub_category, segment, discount, sales, profit, quantity FROM vw_sales_flat", con)
    con.close()
    bins = [-1, 0, 0.1, 0.2, 0.3, 0.5, 1.0]
    labels = ["1. No discount", "2. Up to 10%", "3. 10-20%", "4. 20-30%", "5. 30-50%", "6. Above 50%"]
    df["band"] = pd.cut(df["discount"], bins=bins, labels=labels).astype(str)
    g = (df.groupby(["year", "region", "category", "sub_category", "segment", "band"], as_index=False)
           .agg(sales=("sales", "sum"), profit=("profit", "sum"), qty=("quantity", "sum"), lines=("sales", "size")))
    g["sales"] = g["sales"].round(2); g["profit"] = g["profit"].round(2)
    return {"cols": list(g.columns), "rows": g.values.tolist()}


def main():
    cube = build_cube()
    html = TEMPLATE.replace("__DATA__", json.dumps(cube, separators=(",", ":"), default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    out = ROOT / "docs" / "index.html"
    out.write_text(html, encoding="utf-8")
    print(f"Dashboard written: {out} ({out.stat().st_size/1024:.0f} KB, {len(cube['rows']):,} cube rows)")


if __name__ == "__main__":
    main()
