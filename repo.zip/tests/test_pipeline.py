"""Smoke tests: run after `python python/run_all.py`.   pytest -q"""
import sqlite3
from pathlib import Path
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "processed" / "superstore.db"
RAW = ROOT / "data" / "raw" / "Sample_-_Superstore.csv"


@pytest.fixture(scope="module")
def con():
    c = sqlite3.connect(DB)
    yield c
    c.close()


def test_row_counts_match_source(con):
    raw = pd.read_csv(RAW, encoding="latin1")
    assert con.execute("SELECT COUNT(*) FROM fact_sales").fetchone()[0] == len(raw)
    assert con.execute("SELECT COUNT(*) FROM vw_sales_flat").fetchone()[0] == len(raw)


def test_totals_reconcile_with_source(con):
    raw = pd.read_csv(RAW, encoding="latin1")
    sales, profit = con.execute("SELECT SUM(sales), SUM(profit) FROM fact_sales").fetchone()
    assert sales == pytest.approx(raw["Sales"].sum(), abs=0.01)
    assert profit == pytest.approx(raw["Profit"].sum(), abs=0.01)


def test_no_orphan_foreign_keys(con):
    orphans = con.execute("""SELECT COUNT(*) FROM fact_sales f
        LEFT JOIN dim_product p ON p.product_key = f.product_key
        LEFT JOIN dim_location l ON l.location_key = f.location_key
        LEFT JOIN dim_customer c ON c.customer_id = f.customer_id
        WHERE p.product_key IS NULL OR l.location_key IS NULL OR c.customer_id IS NULL""").fetchone()[0]
    assert orphans == 0


def test_discount_bands_sum_to_total():
    q13 = pd.read_csv(ROOT / "outputs" / "sql_results" / "q13_discount_band_profitability.csv")
    assert q13["order_lines"].sum() == 9994
    assert q13["profit"].sum() == pytest.approx(286397, abs=6)


def test_deep_discounts_lose_money():
    q14 = pd.read_csv(ROOT / "outputs" / "sql_results" / "q14_profit_impact_of_discounts_above_20pct.csv")
    assert q14["profit_from_deep_discount_lines"].iloc[0] < 0
