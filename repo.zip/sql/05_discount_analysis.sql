-- name: q13_discount_band_profitability
WITH banded AS (
    SELECT *,
        CASE
            WHEN discount = 0    THEN '1. No discount'
            WHEN discount <= 0.1 THEN '2. Up to 10%'
            WHEN discount <= 0.2 THEN '3. 10-20%'
            WHEN discount <= 0.3 THEN '4. 20-30%'
            WHEN discount <= 0.5 THEN '5. 30-50%'
            ELSE                      '6. Above 50%'
        END AS discount_band
    FROM vw_sales_flat
)
SELECT
    discount_band,
    COUNT(*)              AS order_lines,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(100.0 * SUM(CASE WHEN profit < 0 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_lines_loss_making
FROM banded
GROUP BY discount_band
ORDER BY discount_band;

-- name: q14_profit_impact_of_discounts_above_20pct
SELECT
    ROUND(SUM(CASE WHEN discount >  0.2 THEN profit ELSE 0 END), 0) AS profit_from_deep_discount_lines,
    ROUND(SUM(CASE WHEN discount >  0.2 THEN sales  ELSE 0 END), 0) AS sales_from_deep_discount_lines,
    SUM(CASE WHEN discount > 0.2 THEN 1 ELSE 0 END)                  AS deep_discount_lines,
    ROUND(SUM(profit), 0)                                            AS total_profit,
    ROUND(SUM(CASE WHEN discount <= 0.2 THEN profit ELSE 0 END), 0)  AS profit_if_deep_discount_lines_removed,
    ROUND(100.0 * (SUM(CASE WHEN discount <= 0.2 THEN profit ELSE 0 END) / SUM(profit) - 1), 1) AS uplift_pct
FROM vw_sales_flat;

-- name: q15_deep_discount_share_by_subcategory
SELECT
    sub_category,
    COUNT(*) AS lines,
    ROUND(100.0 * SUM(CASE WHEN discount > 0.2 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_lines_over_20pct_discount,
    ROUND(SUM(profit), 0) AS profit
FROM vw_sales_flat
GROUP BY sub_category
ORDER BY pct_lines_over_20pct_discount DESC;

-- name: q16_deep_discount_share_by_region_and_state_top10
SELECT
    state, region,
    ROUND(100.0 * SUM(CASE WHEN discount > 0.2 THEN 1 ELSE 0 END) / COUNT(*), 1) AS pct_lines_over_20pct_discount,
    ROUND(SUM(profit), 0) AS profit
FROM vw_sales_flat
GROUP BY state, region
ORDER BY pct_lines_over_20pct_discount DESC
LIMIT 10;
