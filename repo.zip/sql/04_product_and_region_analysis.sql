-- name: q06_category_performance
SELECT
    category,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(100.0 * SUM(sales)  / (SELECT SUM(sales)  FROM fact_sales), 1) AS pct_of_sales,
    ROUND(100.0 * SUM(profit) / (SELECT SUM(profit) FROM fact_sales), 1) AS pct_of_profit
FROM vw_sales_flat
GROUP BY category
ORDER BY profit DESC;

-- name: q07_subcategory_ranking_within_category
SELECT
    category, sub_category,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(100.0 * AVG(discount), 1) AS avg_discount_pct,
    RANK() OVER (PARTITION BY category ORDER BY SUM(profit) DESC) AS profit_rank_in_category
FROM vw_sales_flat
GROUP BY category, sub_category
ORDER BY category, profit_rank_in_category;

-- name: q08_loss_making_subcategories
SELECT sub_category,
       ROUND(SUM(sales), 0) AS sales, ROUND(SUM(profit), 0) AS profit,
       ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
       ROUND(100.0 * AVG(discount), 1) AS avg_discount_pct
FROM vw_sales_flat
GROUP BY sub_category
HAVING SUM(profit) < 0
ORDER BY profit;

-- name: q09_region_performance
SELECT
    region,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(100.0 * AVG(discount), 1) AS avg_discount_pct
FROM vw_sales_flat
GROUP BY region
ORDER BY margin_pct DESC;

-- name: q10_ten_least_profitable_states
SELECT
    state, region,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(100.0 * AVG(discount), 1) AS avg_discount_pct
FROM vw_sales_flat
GROUP BY state, region
ORDER BY profit ASC
LIMIT 10;

-- name: q11_category_by_region_margin_matrix
SELECT
    category,
    ROUND(100.0 * SUM(CASE WHEN region = 'Central' THEN profit END) / SUM(CASE WHEN region = 'Central' THEN sales END), 1) AS central_margin_pct,
    ROUND(100.0 * SUM(CASE WHEN region = 'East'    THEN profit END) / SUM(CASE WHEN region = 'East'    THEN sales END), 1) AS east_margin_pct,
    ROUND(100.0 * SUM(CASE WHEN region = 'South'   THEN profit END) / SUM(CASE WHEN region = 'South'   THEN sales END), 1) AS south_margin_pct,
    ROUND(100.0 * SUM(CASE WHEN region = 'West'    THEN profit END) / SUM(CASE WHEN region = 'West'    THEN sales END), 1) AS west_margin_pct
FROM vw_sales_flat
GROUP BY category;

-- name: q12_top_5_products_by_profit_and_bottom_5
SELECT * FROM (SELECT 'Top 5' AS bucket, product_name, ROUND(SUM(profit), 0) AS profit, ROUND(SUM(sales), 0) AS sales
               FROM vw_sales_flat GROUP BY product_name ORDER BY SUM(profit) DESC LIMIT 5)
UNION ALL
SELECT * FROM (SELECT 'Bottom 5', product_name, ROUND(SUM(profit), 0), ROUND(SUM(sales), 0)
               FROM vw_sales_flat GROUP BY product_name ORDER BY SUM(profit) ASC LIMIT 5);
