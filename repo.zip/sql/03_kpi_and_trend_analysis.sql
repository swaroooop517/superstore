-- name: q01_overall_kpis
SELECT
    ROUND(SUM(sales), 0)                                  AS total_sales,
    ROUND(SUM(profit), 0)                                 AS total_profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 2)            AS profit_margin_pct,
    SUM(quantity)                                         AS units_sold,
    COUNT(DISTINCT order_id)                              AS orders,
    COUNT(DISTINCT customer_id)                           AS customers,
    ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2)       AS avg_order_value,
    ROUND(100.0 * AVG(discount), 2)                       AS avg_discount_pct,
    ROUND(100.0 * SUM(CASE WHEN profit < 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS loss_making_lines_pct,
    ROUND(SUM(CASE WHEN profit < 0 THEN profit ELSE 0 END), 0) AS total_losses
FROM vw_sales_flat;

-- name: q02_yearly_performance_with_yoy
SELECT
    year,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(100.0 * (SUM(sales)  / LAG(SUM(sales))  OVER (ORDER BY year) - 1), 1) AS sales_yoy_pct,
    ROUND(100.0 * (SUM(profit) / LAG(SUM(profit)) OVER (ORDER BY year) - 1), 1) AS profit_yoy_pct
FROM vw_sales_flat
GROUP BY year
ORDER BY year;

-- name: q03_monthly_trend_with_3m_moving_avg
WITH monthly AS (
    SELECT year_month, SUM(sales) AS sales, SUM(profit) AS profit
    FROM vw_sales_flat GROUP BY year_month
)
SELECT
    year_month,
    ROUND(sales, 0)  AS sales,
    ROUND(profit, 0) AS profit,
    ROUND(AVG(sales) OVER (ORDER BY year_month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 0) AS sales_3m_avg,
    ROUND(100.0 * profit / sales, 1) AS margin_pct
FROM monthly
ORDER BY year_month;

-- name: q04_seasonality_by_month
SELECT
    month, month_name,
    ROUND(SUM(sales) / COUNT(DISTINCT year), 0)  AS avg_sales_per_year,
    ROUND(SUM(profit) / COUNT(DISTINCT year), 0) AS avg_profit_per_year
FROM vw_sales_flat
GROUP BY month, month_name
ORDER BY month;

-- name: q05_best_and_worst_months_by_profit
WITH monthly AS (
    SELECT year_month, ROUND(SUM(profit), 0) AS profit, ROUND(SUM(sales), 0) AS sales
    FROM vw_sales_flat GROUP BY year_month
)
SELECT * FROM (SELECT 'Top 3' AS bucket, * FROM monthly ORDER BY profit DESC LIMIT 3)
UNION ALL
SELECT * FROM (SELECT 'Bottom 3' AS bucket, * FROM monthly ORDER BY profit ASC LIMIT 3);
