-- name: q17_segment_performance
SELECT
    segment,
    COUNT(DISTINCT customer_id) AS customers,
    ROUND(SUM(sales), 0)  AS sales,
    ROUND(SUM(profit), 0) AS profit,
    ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct,
    ROUND(SUM(sales) / COUNT(DISTINCT customer_id), 0) AS sales_per_customer
FROM vw_sales_flat
GROUP BY segment
ORDER BY profit DESC;

-- name: q18_top_10_customers_by_profit
SELECT customer_id, customer_name, segment,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(SUM(sales), 0)  AS sales,
       ROUND(SUM(profit), 0) AS profit
FROM vw_sales_flat
GROUP BY customer_id, customer_name, segment
ORDER BY SUM(profit) DESC
LIMIT 10;

-- name: q19_pareto_share_of_profit_from_top_20pct_customers
WITH cust AS (
    SELECT customer_id, SUM(profit) AS profit FROM vw_sales_flat GROUP BY customer_id
),
ranked AS (
    SELECT customer_id, profit,
           ROW_NUMBER() OVER (ORDER BY profit DESC) AS rn,
           COUNT(*) OVER () AS n,
           SUM(profit) OVER (ORDER BY profit DESC ROWS UNBOUNDED PRECEDING) AS cum_profit,
           SUM(profit) OVER () AS total_profit
    FROM cust
)
SELECT
    COUNT(*) AS top_20pct_customers,
    ROUND(MAX(cum_profit), 0) AS profit_from_top_20pct,
    ROUND(100.0 * MAX(cum_profit) / MAX(total_profit), 1) AS pct_of_total_profit
FROM ranked
WHERE rn <= n * 0.2;

-- name: q20_customers_with_negative_lifetime_profit
SELECT COUNT(*) AS loss_making_customers,
       ROUND(SUM(profit), 0) AS combined_profit
FROM (SELECT customer_id, SUM(profit) AS profit FROM vw_sales_flat GROUP BY customer_id HAVING SUM(profit) < 0);

-- name: q21_rfm_segmentation
WITH ref AS (SELECT julianday(MAX(order_date)) + 1 AS ref_date FROM vw_sales_flat),
base AS (
    SELECT customer_id,
           CAST((SELECT ref_date FROM ref) - julianday(MAX(order_date)) AS INTEGER) AS recency_days,
           COUNT(DISTINCT order_id) AS frequency,
           SUM(sales) AS monetary
    FROM vw_sales_flat GROUP BY customer_id
),
scored AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recency_days DESC) AS r_score,
        NTILE(5) OVER (ORDER BY frequency)         AS f_score,
        NTILE(5) OVER (ORDER BY monetary)          AS m_score
    FROM base
),
labelled AS (
    SELECT *,
        CASE
            WHEN r_score >= 4 AND f_score >= 4 THEN 'Champions'
            WHEN r_score >= 3 AND f_score >= 3 THEN 'Loyal'
            WHEN r_score >= 4 AND f_score <= 2 THEN 'New / Promising'
            WHEN r_score <= 2 AND f_score >= 4 THEN 'At risk (was loyal)'
            WHEN r_score <= 2 AND f_score <= 2 THEN 'Lost / Dormant'
            ELSE 'Needs attention'
        END AS rfm_segment
    FROM scored
)
SELECT rfm_segment,
       COUNT(*) AS customers,
       ROUND(AVG(recency_days), 0) AS avg_recency_days,
       ROUND(AVG(frequency), 1)    AS avg_orders,
       ROUND(AVG(monetary), 0)     AS avg_sales
FROM labelled
GROUP BY rfm_segment
ORDER BY customers DESC;

-- name: q22_repeat_vs_one_time_customers
WITH c AS (SELECT customer_id, COUNT(DISTINCT order_id) AS orders FROM vw_sales_flat GROUP BY customer_id)
SELECT CASE WHEN orders = 1 THEN 'One-time' WHEN orders <= 5 THEN '2-5 orders' ELSE '6+ orders' END AS customer_type,
       COUNT(*) AS customers
FROM c GROUP BY customer_type ORDER BY customers DESC;

-- name: q23_shipping_performance_by_mode
SELECT ship_mode,
       COUNT(DISTINCT order_id) AS orders,
       ROUND(AVG(days_to_ship), 2) AS avg_days_to_ship,
       ROUND(100.0 * SUM(profit) / SUM(sales), 1) AS margin_pct
FROM vw_sales_flat
GROUP BY ship_mode
ORDER BY avg_days_to_ship;
