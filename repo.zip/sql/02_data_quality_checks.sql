-- name: dq01_row_counts
SELECT 'fact_sales' AS table_name, COUNT(*) AS row_count FROM fact_sales
UNION ALL SELECT 'dim_customer', COUNT(*) FROM dim_customer
UNION ALL SELECT 'dim_product',  COUNT(*) FROM dim_product
UNION ALL SELECT 'dim_location', COUNT(*) FROM dim_location
UNION ALL SELECT 'dim_date',     COUNT(*) FROM dim_date;

-- name: dq02_null_and_range_checks
SELECT
    SUM(CASE WHEN sales    IS NULL THEN 1 ELSE 0 END) AS null_sales,
    SUM(CASE WHEN profit   IS NULL THEN 1 ELSE 0 END) AS null_profit,
    SUM(CASE WHEN sales   <= 0 THEN 1 ELSE 0 END)     AS non_positive_sales,
    SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END)    AS non_positive_quantity,
    SUM(CASE WHEN discount < 0 OR discount > 1 THEN 1 ELSE 0 END) AS invalid_discount
FROM fact_sales;

-- name: dq03_ship_before_order
SELECT COUNT(*) AS ship_before_order_rows FROM vw_sales_flat WHERE days_to_ship < 0;

-- name: dq04_duplicate_order_product_lines
SELECT order_id, product_id, COUNT(*) AS lines
FROM vw_sales_flat GROUP BY order_id, product_id HAVING COUNT(*) > 1;

-- name: dq05_product_ids_with_multiple_names
SELECT product_id, COUNT(DISTINCT product_name) AS name_variants
FROM dim_product GROUP BY product_id HAVING COUNT(DISTINCT product_name) > 1
ORDER BY name_variants DESC, product_id LIMIT 10;

-- name: dq06_date_coverage
SELECT MIN(order_date) AS first_order, MAX(order_date) AS last_order,
       COUNT(DISTINCT order_id) AS orders, COUNT(DISTINCT customer_id) AS customers
FROM vw_sales_flat;
