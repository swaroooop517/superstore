-- Star schema for the Superstore analysis (SQLite dialect, portable to PostgreSQL/MySQL with minor changes)
DROP VIEW  IF EXISTS vw_sales_flat;
DROP TABLE IF EXISTS fact_sales;
DROP TABLE IF EXISTS dim_date;
DROP TABLE IF EXISTS dim_customer;
DROP TABLE IF EXISTS dim_location;
DROP TABLE IF EXISTS dim_product;
DROP TABLE IF EXISTS dim_ship_mode;

CREATE TABLE dim_date (
    date_key     INTEGER PRIMARY KEY,   -- yyyymmdd
    full_date    TEXT NOT NULL,
    year         INTEGER NOT NULL,
    quarter      INTEGER NOT NULL,
    month        INTEGER NOT NULL,
    month_name   TEXT NOT NULL,
    year_month   TEXT NOT NULL,         -- yyyy-mm
    day_of_week  TEXT NOT NULL
);

CREATE TABLE dim_customer (
    customer_id   TEXT PRIMARY KEY,
    customer_name TEXT NOT NULL,
    segment       TEXT NOT NULL
);

CREATE TABLE dim_location (
    location_key INTEGER PRIMARY KEY,
    country      TEXT NOT NULL,
    region       TEXT NOT NULL,
    state        TEXT NOT NULL,
    city         TEXT NOT NULL,
    postal_code  TEXT NOT NULL
);

-- NOTE: 32 Product IDs in the raw file map to more than one product name,
-- so the surrogate product_key is built on (product_id, product_name).
CREATE TABLE dim_product (
    product_key  INTEGER PRIMARY KEY,
    product_id   TEXT NOT NULL,
    product_name TEXT NOT NULL,
    category     TEXT NOT NULL,
    sub_category TEXT NOT NULL
);

CREATE TABLE dim_ship_mode (
    ship_mode_key INTEGER PRIMARY KEY,
    ship_mode     TEXT NOT NULL
);

CREATE TABLE fact_sales (
    row_id          INTEGER PRIMARY KEY,
    order_id        TEXT NOT NULL,
    order_date_key  INTEGER NOT NULL REFERENCES dim_date(date_key),
    ship_date_key   INTEGER NOT NULL REFERENCES dim_date(date_key),
    customer_id     TEXT NOT NULL REFERENCES dim_customer(customer_id),
    location_key    INTEGER NOT NULL REFERENCES dim_location(location_key),
    product_key     INTEGER NOT NULL REFERENCES dim_product(product_key),
    ship_mode_key   INTEGER NOT NULL REFERENCES dim_ship_mode(ship_mode_key),
    sales           REAL NOT NULL,
    quantity        INTEGER NOT NULL,
    discount        REAL NOT NULL,
    profit          REAL NOT NULL
);

CREATE INDEX idx_fact_order_date ON fact_sales(order_date_key);
CREATE INDEX idx_fact_customer   ON fact_sales(customer_id);
CREATE INDEX idx_fact_product    ON fact_sales(product_key);
CREATE INDEX idx_fact_location   ON fact_sales(location_key);

-- Flat analytical view: one row per order line with every attribute and derived cost
CREATE VIEW vw_sales_flat AS
SELECT
    f.row_id, f.order_id,
    od.full_date AS order_date, od.year, od.quarter, od.month, od.month_name, od.year_month,
    sd.full_date AS ship_date,
    CAST(julianday(sd.full_date) - julianday(od.full_date) AS INTEGER) AS days_to_ship,
    sm.ship_mode,
    c.customer_id, c.customer_name, c.segment,
    l.country, l.region, l.state, l.city, l.postal_code,
    p.product_id, p.product_name, p.category, p.sub_category,
    f.sales, f.quantity, f.discount, f.profit,
    f.sales - f.profit AS cost
FROM fact_sales f
JOIN dim_date      od ON od.date_key = f.order_date_key
JOIN dim_date      sd ON sd.date_key = f.ship_date_key
JOIN dim_customer  c  ON c.customer_id = f.customer_id
JOIN dim_location  l  ON l.location_key = f.location_key
JOIN dim_product   p  ON p.product_key = f.product_key
JOIN dim_ship_mode sm ON sm.ship_mode_key = f.ship_mode_key;
