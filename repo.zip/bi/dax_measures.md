# DAX measures and calculated column

```DAX
-- Core measures
Total Sales    = SUM ( fact_sales[sales] )
Total Profit   = SUM ( fact_sales[profit] )
Profit Margin %= DIVIDE ( [Total Profit], [Total Sales] )
Units Sold     = SUM ( fact_sales[quantity] )
Orders         = DISTINCTCOUNT ( fact_sales[order_id] )
Customers      = DISTINCTCOUNT ( fact_sales[customer_id] )
Avg Order Value= DIVIDE ( [Total Sales], [Orders] )
Avg Discount % = AVERAGE ( fact_sales[discount] )

-- Loss analysis
Loss-making Lines = CALCULATE ( COUNTROWS ( fact_sales ), fact_sales[profit] < 0 )
Loss-making Lines % = DIVIDE ( [Loss-making Lines], COUNTROWS ( fact_sales ) )
Total Losses = CALCULATE ( [Total Profit], fact_sales[profit] < 0 )

-- Deep-discount impact
Profit from Deep Discounts (>20%) = CALCULATE ( [Total Profit], fact_sales[discount] > 0.2 )
Profit excl. Deep Discounts       = CALCULATE ( [Total Profit], fact_sales[discount] <= 0.2 )

-- Time intelligence (requires dim_date marked as a date table)
Sales PY        = CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( dim_date[full_date] ) )
Sales YoY %     = DIVIDE ( [Total Sales] - [Sales PY], [Sales PY] )
Profit PY       = CALCULATE ( [Total Profit], SAMEPERIODLASTYEAR ( dim_date[full_date] ) )
Profit YoY %    = DIVIDE ( [Total Profit] - [Profit PY], [Profit PY] )
Sales YTD       = TOTALYTD ( [Total Sales], dim_date[full_date] )

-- Share of total
Sales % of Total  = DIVIDE ( [Total Sales],  CALCULATE ( [Total Sales],  ALL ( fact_sales ) ) )
Profit % of Total = DIVIDE ( [Total Profit], CALCULATE ( [Total Profit], ALL ( fact_sales ) ) )

-- Cumulative profit share by customer (for the Pareto chart)
Cumulative Profit % =
VAR CurrentProfit = [Total Profit]
RETURN
DIVIDE (
    SUMX ( FILTER ( ALL ( dim_customer[customer_id] ), [Total Profit] >= CurrentProfit ), [Total Profit] ),
    CALCULATE ( [Total Profit], ALL ( dim_customer ) )
)
```

## Calculated column on `fact_sales` for discount bands
```DAX
Discount Band =
SWITCH (
    TRUE (),
    fact_sales[discount] = 0,   "1. No discount",
    fact_sales[discount] <= 0.1, "2. Up to 10%",
    fact_sales[discount] <= 0.2, "3. 10-20%",
    fact_sales[discount] <= 0.3, "4. 20-30%",
    fact_sales[discount] <= 0.5, "5. 30-50%",
    "6. Above 50%"
)
```

## Sanity check
With no filters applied the report should show **Total Sales $2,297,201**, **Total Profit $286,397** and **Profit Margin 12.5%**,
which match the SQL (`q01_overall_kpis`) and Excel results.
