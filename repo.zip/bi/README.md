# Power BI layer

The star schema in `powerbi_data/` is exported by `python/01_clean_and_build_db.py`, so Power BI (or Tableau) can be
connected to the same clean model that the SQL queries use.

## 1. Load the data (about 5 minutes)
1. Power BI Desktop > **Get data > Text/CSV**, and load all six files in `bi/powerbi_data/`.
2. In Power Query, set `dim_date[full_date]` to **Date** type; leave keys as whole numbers/text as exported.
3. Close & Apply.

## 2. Data model (Model view)
All relationships are **many-to-one, single direction** from the dimension to the fact table.

| From (dimension) | To (fact_sales) |
|---|---|
| `dim_date[date_key]` | `fact_sales[order_date_key]` (active) |
| `dim_date[date_key]` | `fact_sales[ship_date_key]` (inactive, use `USERELATIONSHIP` if needed) |
| `dim_customer[customer_id]` | `fact_sales[customer_id]` |
| `dim_location[location_key]` | `fact_sales[location_key]` |
| `dim_product[product_key]` | `fact_sales[product_key]` |
| `dim_ship_mode[ship_mode_key]` | `fact_sales[ship_mode_key]` |

Mark `dim_date` as the date table (Table tools > Mark as date table > `full_date`).

## 3. Measures
Create the measures in `dax_measures.md` in a dedicated `_Measures` table.

## 4. Report pages (suggested layout)
**Page 1: Executive summary**
- KPI cards: Total Sales, Total Profit, Profit Margin %, Orders, Average Order Value, Loss-making Lines %
- Combo chart: Sales and Profit by Year, with Margin % line
- Slicers: Year, Region, Category, Segment

**Page 2: Product and discount analysis**
- Bar chart: Profit by Sub-Category (conditional colour: negative = red)
- Column chart: Profit by Discount Band (use the `Discount Band` calculated column from `dax_measures.md`)
- Scatter: Avg Discount % (x) vs Profit Margin % (y) by State, size = Sales
- Matrix: Category x Region with Profit Margin % and a colour scale

**Page 3: Customers**
- Top 10 customers by profit (table with data bars)
- Customer Pareto (line chart of cumulative profit share)
- Donut: customers by segment

## 5. Publish and showcase
- Save as `bi/Superstore_Dashboard.pbix`, then add screenshots of each page to `docs/images/` and link them in the main README.
- Optional: Power BI Service > **File > Embed report > Publish to web** and paste the public link in the README.
  (Use only non-sensitive data; this dataset is public sample data, so it is fine.)
